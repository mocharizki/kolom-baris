package com.example.kolom_baris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
